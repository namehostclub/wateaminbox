import{J as o}from"./index-DgwHW6IL.js";const e={name:"arrow-left",size:24,node:[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]};e.node;const a=o(e);export{a as A};
